const {news}=require('../../lib');
exports.handler=async(e)=>{const q=e.queryStringParameters||{},d=await news(String(q.s||q.q||'forex').slice(0,40));return{statusCode:d?200:502,headers:{'Content-Type':'application/json','Cache-Control':'public, max-age=60'},body:JSON.stringify(d||[])}};
