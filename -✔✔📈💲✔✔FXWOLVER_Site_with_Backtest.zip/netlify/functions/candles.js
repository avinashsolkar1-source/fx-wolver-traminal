const {candles}=require('../../lib');
exports.handler=async(e)=>{const q=e.queryStringParameters||{};const d=await candles(String(q.s||''),String(q.i||'1h'));return{statusCode:d?200:502,headers:{'Content-Type':'application/json','Cache-Control':'public, max-age=10'},body:JSON.stringify(d||[])}};
