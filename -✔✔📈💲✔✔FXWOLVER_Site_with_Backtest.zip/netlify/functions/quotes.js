const {quote}=require('../../lib');
exports.handler=async(e)=>{const o={};await Promise.all(String((e.queryStringParameters||{}).s||'').split(',').filter(Boolean).slice(0,150).map(async s=>{o[s]=await quote(s)}));return{statusCode:200,headers:{'Content-Type':'application/json','Cache-Control':'public, max-age=3'},body:JSON.stringify(o)}};
