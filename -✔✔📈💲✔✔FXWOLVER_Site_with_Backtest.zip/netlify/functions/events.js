// Stateless stub (same as api/events.js). For production save the POST body to your database (e.g. Supabase) here.
exports.handler=async(e)=>({statusCode:200,headers:{'Content-Type':'application/json','Cache-Control':'no-store'},body:JSON.stringify(e.httpMethod==='POST'?{ok:true,stored:false}:[])});
