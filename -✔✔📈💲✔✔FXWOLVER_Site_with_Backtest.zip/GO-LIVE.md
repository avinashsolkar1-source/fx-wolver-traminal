# FX WOLVER: go-live checklist (v4.8)

## What opens where
- `/` website · `/prop/` prop firms · `/trader/` real traders · `/partner/` partner console · `/legal/`
- `/terminal/` **the full terminal** (every "Open terminal" button on the site goes here)
- `/terminal-lite/` the small clean terminal (kept as a backup)
- `/terminal-full/` same terminal as `/terminal/` (the style and script files live in this folder, do not delete it)

## Real prices, chart and news (important)
The terminal reads `/api/quotes`, `/api/candles` and `/api/news` (Yahoo Finance, no key). They need the server functions:
1. **Vercel** (easiest): upload the whole folder to GitHub, import in vercel.com. `api/` and `public/` work as they are.
2. **Netlify**: deploy from GitHub or with the Netlify CLI (`netlify deploy --prod`). `netlify.toml` already maps `/api/*` to `netlify/functions`. Plain drag-and-drop of the folder may publish only the pages and not the functions.
3. **Your own server / PC**: `node server.js` (or `start.bat`), then open http://localhost:3000.
Until the functions run, the terminal shows a clear **SAMPLE DATA** bar with simulated prices. Nothing simulated is shown as real.
If the data server lives on another address, put it in `public/config.js` (`API`).

## Fill in before launch
- `public/config.js`: `BROKER_NAME`, `BROKER_LINK` (the website shows "coming soon" while empty).
- `public/terminal-full/specs.js`: real swap and commission for your firm or broker (`SWAP`, `COMM`). They are sample values now.
- Supabase login, server-side trade history and payouts: not connected yet (the login in the terminal is a preview screen). The database design is in `database/schema.sql`.
- `public/legal/index.html`: have a lawyer review before real money.
- Account types: add `&plan=1phase`, `&plan=2phase` or `&plan=instant` to the link.
- Prop firms: open `/terminal/?firm=name&name=Display%20Name&color=%23ff6a00` (see the Partner page).

## Quick test after deploy
1. Open `/terminal/`: the status bar at the bottom should say LIVE (green dot), not SAMPLE DATA.
2. Click a symbol: chart loads. Click **i**: symbol info opens. News tab shows LIVE NEWS.
3. Place a paper BUY and SELL, set SL and TP, close the trade.
4. On a phone: the icon bar under the top bar opens Watchlist, Chart, Trades, News and the rest.
