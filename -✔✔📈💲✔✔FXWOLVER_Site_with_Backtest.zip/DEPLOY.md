# FXWOLVER: go live (step by step)

## Option A: Vercel (easiest, free)
1. Create a free account at github.com and a new repository. Upload everything from this folder (drag and drop works).
2. Go to vercel.com, sign in with GitHub, press **Add New > Project**, pick the repository, press **Deploy**. No settings to change.
3. Open the link Vercel gives you. Website = `/`, terminal = `/terminal/`.
4. Your domain: Vercel > Project > Settings > Domains > add `fxwolver.com` and follow the DNS steps.

## Option B: your own PC or server
Install Node.js 18+, double-click `open_fxwolver.bat` (Windows) or run `node server.js`. Open http://localhost:3000

## Before you share it with customers
- Change the emails in `public/index.html` (`sales@fxwolver.com`, `partners@fxwolver.com`).
- Prices are in the `#pricing` section of `public/index.html`.
- Terminal login is still a preview. Real login (Supabase) and server-side trades are the next build.
- Market data is the free Yahoo / Binance feed. For paying customers use a licensed data feed.
- Prop firm link example: `https://yourdomain.com/terminal/?firm=acme&name=ACME%20Funded&color=%23ff6a00`

## v2.2 notes
`/partner/` is static and deploys with `public/`. On Vercel, `/api/events` does not store anything; for production, save events to a database (e.g. Supabase) inside `api/events.js`. Run locally with `node server.js` to keep events in memory.
