# Upload to Cloudflare Pages (drag and drop)

1. Cloudflare dashboard > Workers & Pages > Create > Pages > **Upload assets**.
2. Name the project, then upload **FXWOLVER_Cloudflare_v4_16.zip** (the site is at the root of the zip; do not unzip into a folder first).
3. Deploy. Open `https://<project>.pages.dev/`.

What works after the drag-and-drop upload:
- Website, `/terminal/`, `/prop/`, `/trader/`, `/partner/`, `/legal/`, the 3 HD films.
- `_worker.js` (included) serves `/api/quotes`, `/api/candles`, `/api/news`, `/api/events` from Cloudflare, with real prices from Yahoo Finance (Stooq fallback). No setup needed. If the feed is unreachable the terminal shows the labelled SAMPLE DATA bar instead.

Still to do by you:
- Broker link: edit `config.js` (BROKER_NAME, BROKER_LINK).
- Supabase login and server-side trade history are not connected (the terminal login is a preview screen).
- Swap and commission numbers in the instrument info are sample values. Legal pages need a lawyer's review.
- `/api/events` does not store anything yet (returns `stored:false`).
