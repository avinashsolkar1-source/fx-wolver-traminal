# FXWOLVER Trading Terminal

Professional dark trading terminal. Forex 60% · Crypto 30% · US Stocks 10%.

## v2.1: Website upgrade
- Scroll progress bar, sticky nav with active link and mobile menu, animated hero (moving glow, rotating word, count-up stats), live markets marquee, hover spotlight on cards, candle draw-in animation on the terminal preview.
- New: "What is included" comparison table (Normal vs Prop Firm), contact form (opens an email to sales@fxwolver.com), full footer, SEO tags, robots.txt.
- See `DEPLOY.md` for the step-by-step go-live guide.

## v2.0: Live-ready website
- Website opens with the same splash animation as the terminal, then: hero with live price strip (hidden if the data API is not reachable), terminal section, features, For prop firms, **Pricing (Normal $800, Prop Firm $1,200)**, How it works, FAQ.
- No prop programs on the website. The terminal is sold to traders (Normal) and to prop firms (Prop Firm).
- Challenge rules (target, daily loss, max loss, days) are OFF for normal users and ON when the terminal is opened with a `?firm=` link.
- Deploy on Vercel: upload this folder to GitHub, import the repo in vercel.com (`api/` gives live data, `public/` is the site, `.vercelignore` skips backend/frontend/database). Or run `open_fxwolver.bat` locally.
- Change prices in `public/index.html` (section `#pricing`) and sales emails (`mailto:` links).

## v1.9: Login stays, white-label for prop firms
- **Stay logged in:** after you log in once, opening the site goes straight to the terminal. Menu -> Website opens the website again (`/?site=1`). Log out brings the website back.
- **White-label link:** `/terminal/?firm=acme&name=ACME%20Funded&color=%23ff6a00&logo=https://.../logo.png` brands the terminal for another prop firm (name, accent color, logo).
- **Trades to the prop firm:** every open and close is sent with `window.postMessage` (`type:"fxw.trade"`, `event:"open"|"close"`) to the page that embeds the terminal in an iframe. Example is on the website under "For prop firms".
- Not done yet: server-side trade storage, single sign-on, partner admin dashboard.

## v1.8: Website + terminal
- `public/index.html` is now the **website** (landing, features, programs, FAQ). The terminal moved to `public/terminal/index.html` (open at `/terminal/`). The website can also load the terminal inside the page ("Open the terminal here").
- Works with `open_fxwolver.bat` (localhost:3000 = website, localhost:3000/terminal/ = terminal) and on Vercel (same folders).
- Program numbers on the website (One Phase / Two Phase / Funded) are defaults; change them in `public/index.html`. Terminal rules are in the `CONFIG` object at the bottom of `public/terminal/index.html`.

## What's new in v1.7 (Prop challenge rules)
- **Challenge mode** (header chip "Phase 1 · Active"): profit target, daily loss, max loss and min trading days, checked every second on equity (open trades included).
- Breach = all trades closed, pending orders cleared, trading locked, "Challenge failed" banner with Retry. Target + min days met (no open trades) = Passed, then Next phase (Phase 1 -> Phase 2 -> Funded with profit-split display).
- Warning toast at 80% of a loss limit. Reset button is disabled while challenge mode is on.
- **Change the rules** in one place: the `CONFIG` object at the bottom of `public/index.html` (size, dailyLoss, maxLoss, phases, day reset hour). Defaults: $10,000, 5% daily, 10% max, 8% / 5% targets, 5 min days.
- Turn challenge mode off in the panel to use the terminal as a free paper account.
- NOTE: state is still saved in the browser, so this is for demo/testing. For real challenges the same rules must run on the server (next phase).

## What's new in v1.6
- **Order type: Market / Limit / Stop** in the order panel, with an entry-price box (± buttons). It tells you which side is valid (Buy Limit below, Sell Limit above, Buy Stop above, Sell Stop below). The entry line shows on the chart and can be dragged.
- **Loss and profit in dollars before you trade:** SL / TP distance chips or typed prices draw lines on the chart with the $ amount, lots and pips (both Buy and Sell side for market orders).
- Trade box has **− / +** lot buttons; the STOP label shows $ loss, lots and % of equity.

## What's new in v1.5 (more Match-Trader features)
- **Technical summary** in the order panel: Strong Buy / Buy / Neutral / Sell / Strong Sell from 7 indicator votes on the chart you are viewing (not advice).
- **Symbol info** (ⓘ button): contract size, pip, leverage, margin, spread, data source, market status.
- **Market overview** (header): live heat map of every symbol, and a currency strength meter (USD, EUR, GBP, JPY, AUD, NZD, CAD, CHF).
- **Notifications** (header bell): fills, SL / TP hits, alerts, with unread badge.
- Positions: **Reverse** (⇄), **Close winners**, **Close losers**, **Export CSV** of closed trades.
Not included (needs paid / licensed data or a broker): economic calendar, news feed, swap rates, real broker connection.

## What's new in v1.4
- One **Reset** button only (top right). The duplicate "Reset account" in the trades bar is gone.
- Header shows **Today** P/L; margin level turns amber / red when low.
- New **Equity** tab: equity curve + stats (net, win rate, profit factor, avg win/loss, best/worst, max drawdown).
- Live **Open P/L** total in the trades bar.
- Keyboard: **B** long box, **S** short box, **A** alert, **?** shortcut list (also the Shortcuts button in the status bar).

## What's new in v1.3 (SL / Target on the chart)
- **Trade box** (Long L▲ / Short S▼ buttons in the chart toolbar, order-panel buttons, or right-click menu): draws entry, Stop Loss and Target on the chart with live $ risk / reward, pips, R:R and % of equity. Drag SL / TP (or the entry for a pending order), then press **BUY / SELL** on the chart. ⇅ flips side, ⚖ sizes lots from your risk %, ✕ cancels.
- Click at the current price = market order; click elsewhere = Limit / Stop order.
- Open positions on the chart now show **+SL / +TP / ✕ close** buttons, and SL / TP tags with $ and pips (and R for targets). Drag the lines to move them.
- SL / TP typed in the order panel are previewed as draft lines on the chart.

## What's new in v0.7 (cTrader / Match-Trader style)
- Right-side **Order panel**: big SELL/BUY, lot chips, SL/TP distance chips (pips / points / $), live margin, value per pip, risk & reward preview.
- **Risk manager**: type "% risk" and press *Set lots from SL* to size the trade.
- **Pending orders** (Buy/Sell Limit & Stop): right-click the chart -> place; they fill automatically; Pending tab with Cancel.
- **Drag SL / TP / pending lines** on the chart. Drag the price axis to zoom vertically (double-click axis to reset).
- Chart types: Candle, **Heikin-Ashi**, **Bars**, Line, Area.
- Right-click menu: Buy/Sell Limit/Stop here, alert at price, horizontal line, copy price. Bell button = click-to-place alert.
- Live **ticker tape**, **symbol tabs**, improved positions table.
- Positions table: **BE** (stop to break-even), **½** (close half), **TS** (trailing stop), Exit.
- Removed leftover simulation code: no simulated prices anywhere in this build. Spread is estimated for Yahoo symbols (Yahoo gives one price); crypto uses real Binance bid/ask.
All prices stay real (Yahoo Finance / Binance). Paper money only.

## Run it (Windows, easiest)
1. Install Node.js LTS from https://nodejs.org (one time).
2. Extract this zip.
3. Double-click `open_fxwolver.bat`. Your browser opens http://localhost:3000.

## Data honesty
- Only real prices are shown. A symbol is **LIVE** (green), **MARKET CLOSED** (last real price) or **OFFLINE** (no feed).
- Crypto becomes LIVE from the free Binance public API when your network can reach it
  (no API key; Binance.com is not available in some countries, e.g. the USA).
- Forex, gold and US stocks come from Yahoo Finance (Stooq fallback) through server.js. Click the status bar for a data check.
- Trading is paper only (virtual $10,000). No real money, no broker.

## Phases
1. Dashboard, responsive layout, Market Watch, charts  <- done (this version)
2. Real data: Crypto (Binance), Forex (OANDA practice, Dukascopy history), Stocks (Twelve Data / Alpaca)
3. Indicators, drawing tools, alerts
4. Paper trading with Stop Loss / Take Profit
5. Database, history, statistics, backtesting
6. Mobile polish, security, broker demo integration
7. Advanced features, production

`public/` is the working terminal. `frontend/` (React + Vite) and `backend/` (FastAPI) are the
planned production stack and are not used by `open_fxwolver.bat`.

## v0.4 (Phase 1.1)
- Real data: Binance (crypto) + Yahoo Finance via `server.js` (forex, gold, US stocks). Needs Node 18+ and internet. If a source is unreachable that symbol shows OFFLINE.
- Weekend / after-hours: badge shows MARKET CLOSED with the last real price and its time.
- Confirmation dialog for BUY / SELL / Exit: ask every time, ask only once, or off. Stop Loss / Take Profit, Close all, EMA 20/50, entry lines on chart, startup animation.

## v0.5
- Only real data is shown; if a feed is down the symbol shows OFFLINE and retries. Yahoo Finance with Stooq fallback.
- Phone: big BUY/SELL order bar under the chart. Chart: Candles/Line/Area, EMA, Bollinger, price alerts (with sound), history stats.

## Online (phone, anywhere)
Put this folder on GitHub, import it in vercel.com (free). `api/` + `lib.js` give the live data; `public/` is the site.

## v0.6 (this version)
- **Indices**: 12 main world indices (US30, US500, NAS100, US2000, GER40, UK100, FRA40, EU50, ESP35, JP225, AUS200, HK50) with country tags. Real data from Yahoo Finance. US indices use 24h futures (like broker CFDs). Yahoo index quotes can lag a few minutes; bid/ask spread is estimated around the real price.
- **Candle timer**: countdown to candle close under the last price on the right axis. Switch it off in Chart Settings.
- **Chart Settings** (gear): candle timer, grid, last price line, OHLC legend, trade lines, hollow candles, Local/UTC time, 4 colour sets, save chart image, reset.
- **Indicators**: EMA 20/50, SMA 200, Bollinger, Volume, RSI, MACD panels.
- **Drawing tools**: horizontal line, trend line, zone/box (for POI), Fibonacci, measure (pips, %, bars, time), undo, clear. Click a drawing to select it, Delete to remove. Saved per symbol.
- **Trade lines on chart**: entry, SL, TP with live P/L tag and shaded profit/loss zones.
- **Entry / exit confirmation**: entry shows price, risk $, reward $, R:R, margin. Exit shows entry, exit, held time, result. History shows what closed it (MANUAL / SL / TP).
- Keys: 1-6 timeframe, F focus mode, Esc cancel tool, Del remove drawing.

## v1.0 (Phase 1.10): TradingView-style chart settings + time controls
- **Settings window** (gear button or right-click > Chart settings): tabs Symbol, Status line, Scales & lines, Canvas, Trading, Time.
  Custom up/down candle colors, hollow candles, high/low labels, watermark, status line items, Regular / Log / Percentage / Inverted price scale,
  previous-close and Bid/Ask lines, background + grid colors, crosshair style, day separators, trade-line toggles, order confirmation, 17 time zones, 12/24-hour clock.
- **Time bar** under the chart: 1D 5D 1M 3M 6M YTD 1Y All (auto-switches timeframe), Go to date, time zone selector with live clock, % / log / invert / Auto.
- Only `public/index.html` changed. No database, config or backend file was touched.

## v1.1: price quick-action menu
- Hover the chart: a **+** button appears on the price axis (like TradingView). Click it, **hold** (long-press on phone), or right-click to open the price menu.
- Menu shows the price with distance from now (pips, %), then: Buy/Sell Limit or Stop at that price, **Set Stop Loss / Take Profit here** for your open positions, alert, horizontal line, copy price, chart settings.
- Turn the + button off in Settings > Trading.

## v1.2: more markets + watchlist tools
- **Forex:** 27 pairs (majors + 18 crosses). **Commodities:** Gold, Silver, Platinum, Palladium, WTI, Brent, Natural Gas, Copper. **US stocks:** 19. Indices: 12 (unchanged). Crypto: 6.
- Market Watch: new **Commodities** tab, **star favourites** (★ Favs tab), press **/** to search.
- Footer: Sydney / Tokyo / London / New York **session open** lights (approx. UTC hours).
- `server.js` and `api/quotes.js`: quote limit raised from 40 to 150 symbols per request (needed for the bigger list). Nothing else in backend/database changed.

## v2.2 — Partner Console and risk/reward feed

- `/partner/` — Partner Console: live feed, per-trader table (equity, open risk, win rate, avg R, challenge status), high-risk alerts, copyable connect snippets.
- Terminal events (`type: "fxw.trade"`): `open`, `modify`, `close`, `snapshot`. Each carries `riskUsd`, `rewardUsd`, `rr`, `riskPct`; closes carry `pnl`, `rMultiple`, `plannedRR`.
- Channels: `window.postMessage` to the embedding page, `BroadcastChannel('fxw-events')`, optional webhook `?hook=https://…`, and `POST /api/events` (local server keeps the last 3000 in memory).
- URL params: `?firm=` `?name=` `?color=` `?uid=<trader id>` `?hook=`. A `uid` skips the preview login gate.
- Website: new Connect, Risk analytics and Status sections plus animation layer.

Not included yet: database storage of events (Vercel `api/events.js` is a stateless stub), signed webhooks, SSO, broker connection, real accounts/payments.

## v2.3 — separate paths
- `/prop/` Prop firm page, `/trader/` Real trader page (Match-Trader style layout), home has a side-by-side "Choose your path" section.
- Broker link: edit `public/config.js` (`BROKER_NAME`, `BROKER_LINK`). While empty the trader page shows "Coming soon"; once filled the button opens your broker.

## v2.4 — Prop challenge dashboard
In prop mode (`?firm=…`) the 🛡 chip opens a full Match-Trader-style dashboard: phase stepper, balance/equity, objectives table with progress, equity vs rule lines, trading stats, daily P/L calendar, payout card (disabled in sandbox), challenge trades and leaderboard (own row until a firm connects traders).

## v2.5 — effects layer
`public/fx.css` + `public/fx.js`: aurora background, word-by-word heading reveal, drifting price-line hero canvas, cursor ring, card tilt, auto-advancing feature showcase, and an interactive position-size calculator (estimates). All effects respect `prefers-reduced-motion`.

## v2.7
Glow logo above the terminal section; animated laptop → mobile device showcase (`#devices`). A ready-made video of it is delivered separately as FXWOLVER_Laptop_to_Mobile.mp4. The website no longer auto-redirects to the terminal.

## v2.8 — 3D cinematic
`scene3d.js` + `scene3d.css` render a live 3D scene (laptop opens, phone flies in, prop dashboard) on the home page (`#cinema`). `media/fxwolver-3d.mp4` is a 1080p 30fps render of the same scene (replace it with your own video if you like; keep the filename). All numbers are sample numbers.

## v2.9 — smooth videos + more sections
- Both videos re-rendered frame by frame (30fps, 1080p): no stutter, and the phone/cards stay fully inside the frame (bounds-checked).
- Home `#cinema` now plays the two pre-rendered mp4s (lazy-loaded, autoplay muted when visible, fullscreen button with controls). The heavy live 3D scene is no longer loaded (`scene3d.*` kept only for re-rendering).
- New sections: live Forex market sessions clock, 72-instrument explorer with search, trading basics (accordion + break-even calculator), back-to-top button.
- All numbers in animations are sample numbers. Deposits/withdrawals and real accounts stay disabled (sandbox).

## v3.0 — more website
Announcement bar, prop challenge simulator (`#challenge`, example rules), Normal vs Prop compare table, roadmap, cookie notice, `/legal/` page (risk, terms, privacy: draft, have a lawyer review), footer legal links. Files: `extra2.css`, `extra2.js`.

## v3.1 — terminal ticket + videos (final)
- Terminal: order ticket v3 (big live bid/ask buttons, tick sparkline, lot stepper, margin / risk / reward cards, fill animation) plus v4: **Open-position card** with live P/L and Close, **Size by risk** (0.5 / 1 / 2 / 3 % of balance from your Stop Loss), and a lot stepper on the mobile order bar. Trading logic untouched.
- All four films (`media/*.mp4`) now end with a motion-graphic outro (light sweep, price line draw, logo rings, title, chips, call-to-action). Stable 30fps pre-rendered files.
- Netlify: `netlify.toml` + `netlify/functions` (quotes, candles, events) so `/api/*` works on Netlify. Deploy with the Netlify CLI or Git (a plain folder drag-and-drop does not run functions; without them the terminal shows OFFLINE instead of prices). Vercel still works through `api/`.
- Supabase is not connected yet: events/login are stubs. Add your keys in `config.js` and save events in `netlify/functions/events.js` when you build the real login.
- Real deposits/withdrawals stay disabled (sandbox).

## v3.2
- Fixed: SELL/BUY buttons in the home page terminal preview were clipped on phones (class name clash with the sessions bar). Buttons are now large with live-style prices and spread chip (illustration).
- Prop page: "What a real prop firm needs" checklist (built / partial / needs setup), Match-Trader style.

## v3.3
New prop-firm film (`media/propfirm-demo.mp4`, 20s): 3D control room with Partner Console, challenge dashboard (Phase 1 → Phase 2 → Funded), equity vs limits, white-label colour switch, sandbox payout card, and the motion-graphic outro. The trader film is unchanged.

## v3.4
"Why FX WOLVER" bento with animated visuals, final call-to-action band with an animated candlestick skyline and aurora, wolf watermark and a 5-column footer with Legal links. Files: `extra3.css`, `extra3.js` (pause when off-screen, respect reduced motion).

## v3.5 — final touch
SEO/OG meta on every page, web app manifest + icons (add the terminal to a phone home screen), branded `404.html` (served with 404 by `server.js`; Netlify uses it automatically), skip-to-content link, visible keyboard focus, smooth anchor scrolling, fuller mobile menu (films, markets, challenge, roadmap, legal). All pages checked on desktop and phone width: no JS errors, no horizontal scroll.

## v3.6 — terminal matches the films
Terminal now has the same pieces you see in the videos: a glass **TRADE OPENED** card (side, lots, Risk, Reward, R:R), a live **position pill** on the chart (symbol, side, lots, live P/L), and in prop mode a **Challenge HUD** on the chart (phase status, daily loss limit and profit target bars). Visual layer only; trading logic untouched.

## v3.7 — sample data mode
If no live feed is reachable (offline, or no `/api` functions), the terminal now falls back after ~6 s to clearly labelled **SAMPLE DATA**: simulated prices and candles for all 72 instruments so the chart, BUY/SELL, risk tools and challenge HUD can be seen working. An amber bar says "SAMPLE DATA MODE · not real market prices" (button *Turn off*), the chart badge says "SAMPLE DATA", and the status bar shows SAMPLE DATA. The moment a real feed connects, real prices take over automatically. Paper trades and challenge numbers made on sample data are simulated too; press Reset to clear them.

## v4.0 — clean terminal (as in the film)
`/terminal/` is now a clean, minimal terminal that looks like the film: watchlist (EURUSD, GBPUSD, XAUUSD, BTCUSD, US30, NAS100), 1H candle chart with EMA and TARGET / entry / STOP lines, SELL / BUY panel (lots, Stop Loss $, Take Profit $, R:R, profit target, daily loss), PHASE 1 · ACTIVE chip, bottom position strip with live P/L and a TRADE OPENED card. Live prices through `/api/quotes` and `/api/candles`; with no feed it shows clearly labelled SAMPLE DATA. `?name=` sets the brand name.
The previous full terminal (all tools, prop dashboard, partner event feed) is kept untouched at `/terminal-full/` so features can be added back one by one.
