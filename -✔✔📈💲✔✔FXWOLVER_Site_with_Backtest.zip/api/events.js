// Vercel serverless functions have no memory between calls, so events are NOT stored here.
// The terminal also sends events by postMessage, BroadcastChannel and your own ?hook= URL.
// For production: save req.body into your database (for example Supabase) in this file.
module.exports=(req,res)=>{res.setHeader('Cache-Control','no-store');
  if(req.method==='POST')return res.status(200).json({ok:true,stored:false});
  res.status(200).json([]);};
