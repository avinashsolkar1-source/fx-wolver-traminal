const {news}=require('../lib');
module.exports=async(req,res)=>{const d=await news(String(req.query.s||req.query.q||'forex').slice(0,40));res.setHeader('Cache-Control','s-maxage=60,stale-while-revalidate=120');res.status(d?200:502).json(d||[]);};
