# Terminal new look (v4.3, FX WOLVER identity)
- Changed only: `public/terminal-full/index.html` (2 lines at the end load the skin) + new files `public/terminal-full/skin.css` and `skin.js`.
- Chart, watchlist, order logic, database and website pages are untouched.
- Back to the old look: remove the two `skin.css` / `skin.js` lines at the end of `public/terminal-full/index.html`.
- Laptop: top bar (Trade / Analytics / Explore, Profit, Equity), watchlist + quick trade card + symbol info on the left, chart and Open Positions / Pending Orders / Closed Positions / Finance on the right. "Advanced Order" opens the full order panel as a drawer.
- Phone: compact top bar, bottom bar (Markets / Chart / Trades), quick trade card on the Markets screen, orders under the chart, extra items in the menu.
- Easy to use: first-visit Quick Tour (also the ? button and menu) with highlights.
- The site buttons still open `/terminal/` (small page). The full terminal with the new look is `/terminal-full/`.
- v4.3: own identity (midnight blue, royal blue + violet, silver, wolf mark), underline tabs, own tab names (Positions / Orders / History / Performance), status bar (feed status, session, account, open trades, margin, clock, shortcuts).
- v4.4: every instrument has an **i** button (watchlist rows, quick trade card, chart toolbar, key `I`). It opens a full information dialog: contract specification, margin and leverage, spread, commission, swap long/short, triple-swap day, trading hours, a position calculator and a cost estimator. Files: `public/terminal-full/specs.js` + `specs.css`. Swap and commission are a SAMPLE schedule (not charged to the paper balance): edit the `SWAP` and `COMM` tables at the top of `specs.js` to your firm's real values. To remove: delete the two `specs` lines at the end of `terminal-full/index.html`.
- v4.5: **News** panel under the watchlist (tabs: News / Calendar / Heatmap / Instrument; on phones it is in the ☰ menu). Real headlines come from `/api/news` (Yahoo Finance, no key) for the selected symbol or the whole market class, refreshed every 2 minutes. If the feed is not reachable it shows placeholders clearly labelled SAMPLE. Files: `terminal-full/news.js` + `news.css`, `lib.js` (news), `api/news.js`, `netlify/functions/news.js`, `server.js`, `netlify.toml`.
- Real data: prices (`/api/quotes`, `/api/candles`) and news already use real feeds when the site runs with its functions (local `server.js`, Vercel, or Netlify via Git/CLI). Until then the terminal shows SAMPLE DATA (labelled). To use a data server on another address, set `API` in `public/config.js`.
- v4.6: own look (wolf icon rail on the left, glass cards, new quick-trade card, watchlist sparklines) and a **chart switch**: *Pro chart* (own chart: drag SL/TP lines, trade box, drawings, indicators) or *TradingView* (official TradingView widget, needs internet; symbol and timeframe follow your selection). Under the TradingView chart a trade strip gives SELL / lots / BUY, Stop Loss, Take Profit, live risk / reward / R:R and your open positions of that symbol. The TradingView widget cannot draw your SL/TP lines on its own chart (TradingView does not allow that in the free widget), that is why the strip exists. Files: `terminal-full/look.js` + `look.css`. Your choice is remembered. To remove: delete the two `look` lines at the end of `terminal-full/index.html`.
- v4.7: **Trade dock** under the chart on laptop (SELL / lots / BUY, SL, TP, risk and reward, Long / Short box, Close all, Pro order; works with Pro chart and TradingView). **Maximize / Minimize** for the chart (buttons at the top right of the chart, or key `M`, `Esc` to return). **Drawing tools** are grouped and named (button at the top of the tool bar shows or hides the names): Trend line, Ray, Horizontal, Vertical, Arrow, Zone, Fibonacci, Text, Measure, Long / Short box, Alert, Undo, Clear. New drawing types (Ray, Vertical, Arrow, Text) live in `terminal-full/index.html`. Top bar has an animated accent line.
- v4.8: quick trade card smaller; **phone icon bar** under the top bar (Watchlist, Chart, Trades, News, Heatmap, Analytics, Calendar, Journal, Sound); **sound** for fills, Stop Loss and Take Profit (switch in the rail or the phone bar); `/terminal/` is now the full terminal (old small one kept at `/terminal-lite/`); `GO-LIVE.md` checklist; `_headers`. Files: `terminal-full/final.js` + `final.css`.
- v4.9: **account types**. `?plan=1phase|2phase|instant` in the terminal link (the account chip switcher is for testing). 1-Phase and 2-Phase run as **DEMO** and become **LIVE** at the Funded stage; Instant is **LIVE** from the start; no plan = free PAPER. LIVE is the funded stage: orders stay simulated until a broker is connected. **Internet lost**: sound + red bar, repeating beep while trades are open, orders on real prices pause until it is back (sounds are made on the device, so they work offline). Files: `terminal-full/plans.js`, `final.js`. See also `ROADMAP.md`.

## v4.18
- Trader film: phone now stands clear of the laptop (gap, own floor shadow), no overlap with the screen; camera orbit narrowed.

## v4.17
- Films re-encoded for sharper HD within the 30 MB upload limit.

## v4.16
- Cloudflare Pages ready: `public/_worker.js` serves the data routes. Trader film got a bloom/glow pass.

## v4.15
- Website videos: 3 HD (1920x1080) films: Trader view (chart + terminal combined, laptop and phone), FX WOLVER in 3D (your two originals merged), Prop firm view (your earlier second video, upscaled to HD).

## v4.13
- Films 3 and 4 (your original 3D films) added back. Films 1 and 2 rebuilt: dark studio background, laptop and animated phone app (drawing tools, order tap, P/L).

## v4.12
- Both films on the home page replaced: Film 1 = the chart (timeframes, drawing tools, Long/Short boxes, SL/TP, maximize), Film 2 = the full trading terminal (watchlist, instrument info, news, orders, DEMO/LIVE). Recorded from the real terminal as a 3D scene: laptop + phone + floating panels, animated live candles, logo intro/outro (about 35 s each). Files: `public/media/chart-demo.mp4`, `terminal-demo.mp4`, posters. Footage uses SAMPLE prices and says so on screen.
- Video bug fixed: `server.js` now sends `video/mp4`/`webm` MIME and HTTP Range (206). Markup uses `<source>` mp4 + webm, autoplay muted, fallback controls.
- `/terminal/` is now identical to `/terminal-full/` (order-message close ✕ works there).
- New 💬 button (rail) and menu item "Order messages ON/OFF" to hide order messages (errors still show). Saved in `fxw.msg`.
- One Quick Tour only (the `?` button and menu both start it); selector fixed to the order card.

## Phase 2.0 — FX WOLVER Journal
- New page `/journal/` (public/journal/index.html, journal.css, journal.js). English-only UI.
- Start effect: animated "FX WOLVER" wordmark + price line, then the logo, then the login-style gate. Skippable; shorter after the first load in a session.
- Gate: name + optional email, or Solo. "Continue with Google" is a placeholder: real Google sign-in and cross-device sync need Supabase URL + anon key (config.js slot, NOT connected).
- Autosave: every edit is saved to localStorage `fxw.journal.v1` (this browser only), with a "Saved ✓" indicator.
- Solo / Connected: Connect imports closed trades from the terminal (`fxw.paper.v1`, `fxw.prop.v1`) and keeps syncing. Disconnect removes all synced (terminal + sample) entries after an in-page confirmation; manual entries stay. The terminal code is untouched.
- Export CSV: download or copy (Date, Source, Symbol, Side, Lots, Entry, Exit, PnL, Verdict, Feeling, Tags, Reason, Has_Screenshot).
- Website: Journal section now links to /journal/ with English labels.
- Videos: media paths are relative, a "▶ Play" button appears if autoplay is blocked, `_headers` sets video/mp4 + Accept-Ranges.
- Journal is embedded at the bottom of the website (#journal section) as a framed app: log in (or Solo) and it opens inside the page. `/journal/` still works full screen. Embed mode (`?embed=1`) skips the splash; name is optional at login.
