// FXWOLVER — zero-dependency server + real market data proxy (Yahoo Finance, no API key). Needs Node 18+.
const http=require('http'),fs=require('fs'),path=require('path');
const PORT=process.env.PORT||3000,PUB=path.join(__dirname,'public');
const MIME={'.html':'text/html; charset=utf-8','.css':'text/css','.js':'text/javascript','.json':'application/json','.png':'image/png','.jpg':'image/jpeg','.webp':'image/webp','.svg':'image/svg+xml','.mp4':'video/mp4','.webm':'video/webm','.woff2':'font/woff2','.ico':'image/x-icon','.webmanifest':'application/manifest+json','.txt':'text/plain'};
const {quote,candles,news}=require('./lib');
const EV=[];/* partner events, kept in memory while the server runs. Production: store them in your database. */
http.createServer(async(req,res)=>{
  const u=new URL(req.url,'http://x'),json=(d,c)=>{res.writeHead(c||200,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify(d));};
  if(u.pathname==='/api/quotes'){const o={};await Promise.all((u.searchParams.get('s')||'').split(',').filter(Boolean).slice(0,150).map(async s=>{o[s]=await quote(s);}));return json(o);}
  if(u.pathname==='/api/news'){const d=await news((u.searchParams.get('s')||u.searchParams.get('q')||'forex').slice(0,40));return json(d||[],d?200:502);}
  if(u.pathname==='/api/candles'){const d=await candles(u.searchParams.get('s')||'',u.searchParams.get('i')||'1h');return json(d||[],d?200:502);}
  if(u.pathname==='/api/events'){
    if(req.method==='POST'){let b='';req.on('data',c=>{b+=c;if(b.length>20000)req.destroy();});req.on('end',()=>{try{const m=JSON.parse(b);if(m&&m.type==='fxw.trade'){m.srv=Date.now();EV.push(m);if(EV.length>3000)EV.splice(0,EV.length-3000);}json({ok:true,stored:true});}catch(e){json({ok:false},400);}});return;}
    const since=+u.searchParams.get('since')||0;return json(EV.filter(m=>m.srv>since).slice(-1000));}
  let up=decodeURIComponent(u.pathname);if(up.endsWith('/'))up+='index.html';else if(up==='/terminal')up='/terminal/index.html';else if(up==='/terminal-lite')up='/terminal-lite/index.html';else if(up==='/partner'||up==='/prop'||up==='/trader'||up==='/legal'||up==='/terminal-full'||up==='/backtest')up+='/index.html';let f=path.join(PUB,up);if(!f.startsWith(PUB))f=path.join(PUB,'index.html');
  fs.readFile(f,(e,b)=>{if(e)return fs.readFile(path.join(PUB,'404.html'),(e2,b2)=>{res.writeHead(e2?500:404,{'Content-Type':'text/html; charset=utf-8'});res.end(e2?'Server Error':b2);});const ct=MIME[path.extname(f).toLowerCase()]||'application/octet-stream',rg=/^bytes=(\d*)-(\d*)$/.exec(req.headers.range||'');
    if(rg&&(rg[1]||rg[2])){let a=rg[1]?+rg[1]:b.length-(+rg[2]),z=rg[1]&&rg[2]?Math.min(+rg[2],b.length-1):b.length-1;if(a>z||a>=b.length){res.writeHead(416,{'Content-Range':'bytes */'+b.length});return res.end()}res.writeHead(206,{'Content-Type':ct,'Accept-Ranges':'bytes','Content-Range':'bytes '+a+'-'+z+'/'+b.length,'Content-Length':z-a+1});return res.end(b.subarray(a,z+1))}
    res.writeHead(200,{'Content-Type':ct,'Accept-Ranges':'bytes','Content-Length':b.length});res.end(b);});
}).listen(PORT,'0.0.0.0',()=>console.log('\n  FXWOLVER is LIVE -> http://localhost:'+PORT+'\n  Real data: Binance (crypto) + Yahoo Finance (forex, gold, stocks)\n'));
